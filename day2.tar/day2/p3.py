L=[16,50,300,5,40,110]
sum=0
for var in L:
    sum+=var   # sum= sum+var
else:
    print(f"Sum of {L} is {sum}")
