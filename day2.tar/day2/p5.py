import os 
L=[]
for i in range(5):
    var=input("Enter the filename")
    L.append(var)

for var in L:
    print(var)

for var in L:
    os.system("ls -l"+var)

    
