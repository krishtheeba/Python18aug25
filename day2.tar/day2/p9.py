with open("C://Users//Lenovo//Desktop//emp.csv","r") as FH:
    c=1
    for var in FH.readlines():
        print("{} \t {} ".format(c,var.strip()))
        c+=1
    
