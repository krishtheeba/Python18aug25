filename="C://Users//Lenovo//python18Aug25//day2//emp.csv"
# filename1=".//emp.csv"
FH=open(filename)
# FH=open(filename1)
L=FH.readlines()
print(f"Total no. of lines in file {filename} is {len(L)}")
FH.close()
