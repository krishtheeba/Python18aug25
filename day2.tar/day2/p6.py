emp=["ram,sales,pune,1000", "kumar,prod,chennai,2000","arun,sales,pune,3000","xerox,HR,mumbai,4500"]
sum=0
for var in emp:   # var='ram,sales,pune,1000'
    name,dept,city,cost=var.split(",")  #name,dept,city,cost= ['ram','sales','pune','1000']
    print("Emp Name : {} \t Working place: {}".format(name,dept))
    sum+=int(cost) # sum=sum+cost

print("="*50)
print("Sum of Emp Cost : {}".format(sum))
print("="*50)
