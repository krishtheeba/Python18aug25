hosts=["host01", "host02","host04","host05"]

if "host03" not in hosts:
    print("host03 Not Available")
    
