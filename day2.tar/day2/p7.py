L=[]
for i in range(5):
    var=int(input("Enter a no"))
    L.append(var)

L.sort()

for var in L:
    print(var)
