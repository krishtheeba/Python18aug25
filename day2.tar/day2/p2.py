fobj=open("C://Users//Lenovo//Desktop//emp.csv")
L=fobj.readlines()
for var in L[-3:]:
    print(var.strip())
fobj.close()
