with open("C://Users//Lenovo//python18Aug25//day2//data.log","w") as WH:
    c=0
    while c<5:
        WH.write("DATA : {}\n".format(c))
        c+=1
        
    
