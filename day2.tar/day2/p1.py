fobj=open("C://Users//Lenovo//Desktop//emp.csv","r")  # open(filename,mode)
L=fobj.readlines() # L=['l1\n', 'l2\n'...'lN \n']
sum=0
for var in L:       #  var= "101,Arun,sales,pune,2000\n"
    v=var.strip()     # v="101,Arun,sales,pune,2000"
    # emp=v.split(",")   # emp=["101","Arun","sales","pune","2000"]
    eid,ename,edept,ecity,ecost=v.split(",")  #eid,ename,edept,ecity,ecost=emp 
    sum+=int(ecost)# sum= sum+int(ecost)
    print(f"Emp name: {ename}\tWorking dept : {edept}")
else:
    print("="*50)
    print(f"Sum of Emp Cost : {sum}")
    print("="*50)
    
fobj.close()
