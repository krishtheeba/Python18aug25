var=input("Enter the var value:")

print(var,type(var))

print(int(var),type(int(var)))


