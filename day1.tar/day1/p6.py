fname="Hari"
lname="Govind"
print(len(fname+lname))      

# (or)
# name=fname+lname
# n=len(name)
# print(n)