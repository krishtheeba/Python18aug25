attempt=1
PIN=1234

while (attempt <=3):
	pin=int(input("Enter the Pin : "))
	if(pin == PIN):
		print("PIN MATCHED - SUCCESS")
		break
	else:
		print("PIN NOT MATCHED - FAILED")

	attempt+=1     # attempt=attempt + 1  

else:
	if(pin != PIN):
		print("="*50)
		print("\t\t PIN BLOCKED")
		print("="*50)