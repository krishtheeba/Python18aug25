i=0
while i<3:
	i+=1
	print("DATA ", i)
	if(i==1):
	 	continue         #break
	print("Inside Loop")
	

print("Outside Loop")