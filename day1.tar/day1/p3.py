# Single Line Comment

""" Multiline
Comment
used
"""

username=input("Enter the Username")
if(username == "root"):
	print("Login Success")
else:
	print("Login Failed")

