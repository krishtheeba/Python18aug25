name=input("Enter the name: ")
mark1=input("Enter the Mark1 Value: ")  # (or)   mark1=int(input("Enter the Mark1 Value: "))
mark2=input("Enter the Mark2 Value: ")  # (or)   mark2=int(input("Enter the Mark2 Value: "))
mark3=input("Enter the Mark3 Value: ")  # (or)   mark3=int(input("Enter the Mark3 Value: "))

sum=int(mark1) + int(mark2) + int(mark3)   #  sum =mark1 + mark2 + mark3

avg=sum/3

print(f"""
==========================
Name	:	{name}
==========================
Mark1   :       {mark1}
==========================
Mark2   :       {mark2}
==========================
Mark3   :       {mark3}
==========================
Total   :       {sum}
==========================
Average :       {avg}
==========================""")





