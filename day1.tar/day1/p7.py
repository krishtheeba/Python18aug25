no=56
item_cost=509.56
desc=""

print(no, type(no))
print(item_cost, type(item_cost))
print(desc, type(desc))

