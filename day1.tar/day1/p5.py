var="Theeba"
print("Hello..", var) 
# print("Hello..%s"%(var))
# print("Hello.. {}".format(var))
# print(f"Hello.. {var}")