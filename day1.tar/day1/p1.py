fstype="xfs"   
fpart="/dev/sda1"
fsize=150

print('''
---------------------------------
      File system Type : {}
--------------------------------
      Partition Name :{}
--------------------------------
      File Size : {} GB
-------------------------------'''.format(fstype,fpart,fsize))

