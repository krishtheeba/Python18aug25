username=input("Enter the Username:")
if(username == "root"):
	shellname=input("Enter Shellname:")
	if(shellname == "sh" or shellname=="bash"):
		print(f"Username : {username}   Shell name : {shellname}")
	else:
		print("Shellname Not Matched")
else:
	print("Login Failed")
