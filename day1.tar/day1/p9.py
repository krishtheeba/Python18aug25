enquiry_no = int(input("Enter the Enquiry number: "))
if (enquiry_no < 600  and enquiry_no > 500):
	quotation_no = int(input("Enter the Quotation number: "))
	if quotation_no <600 and quotation_no > 550:
		customer_name = input("Enter the Customer Name: ")
		if customer_name == "IBM" or customer_name == "ORACLE" or customer_name == "HP"  or customer_name == "KLABS" :
			po_no = int(input("Enter the Purchase Order number: "))
			if po_no <1000 and po_no > 500:
				print("""
Enquiry No : {}
Quotation Number : {}
Customer_Name : {}
PO Number : {}
""".format(enquiry_no,quotation_no,customer_name,po_no))
			else:
				print("PO Number didn't Match !!")
		else:
			print("Customer Name didn't Match !!")
	else:
		print("Quotation No didn't Match !!")
else:
	print("Enquiry Number didn't Match !!")